import neuronxcc.starfish.penguin.ir.ir as m0
import neuronxcc.starfish.penguin.ir.DebugInfo as m1
import neuronxcc.starfish.penguin.targets.tonga.APIndex as m2
import neuronxcc.starfish.penguin.targets.tonga.TongaInst as m3
import neuronxcc.starfish.penguin.targets.tonga.TongaISAInst as m4
import neuronxcc.starfish.penguin.targets.tonga.TongaTensor as m5
import numpy as np
v0 = m0.Function(id_=0, batch_ids=[], attrs=("model-type=memory-bound","mac-count=32768",'hlo-metrics={"AliasedOutputSize":0,"ArithmeticIntensity":1.9844961166381836,"ConstantSize":0,"HloInputCount":-1,"HloMacCount":32768,"HloOutputCount":-1,"IfmapSize":0,"OfmapSize":0,"OutputsReadFromCount":-1,"PassthroughTensorsCount":-1,"RedundantOutputCount":-1,"Traffic":33024}'))
def weight_load(p):
  t = np.load(p)
  return t
import neuronxcc.starfish.support as m7
v1 = m0.Tensor(name="input0", shape=(8,8), parent=v0, id=1, dtype="float32", view=m0.TensorView(shape=(8,8), layout="NC", transpose=(0,1)), attrs={'CrossPassTensor': ""})
v0.markInput(v1)
v2 = m0.Tensor(name="input1", shape=(512,8), parent=v0, id=2, dtype="float32", view=m0.TensorView(shape=(512,8), layout="NC", transpose=(0,1)), attrs={'CrossPassTensor': ""})
v0.markInput(v2)
import neuronxcc.starfish.penguin.frontends.XlaFE as m8
v3 = m0.Tensor(name="output0", shape=(512,8), parent=v0, id=3, dtype="float32", view=m0.TensorView(shape=(512,8), layout="NC", transpose=(0,1)), )
v4 = m8.NativeKernel(srcs=[v2, v1], dsts=[v3], kernel_config='eyJmdW5jX25hbWUiOiAiX19tYWluX18ua2VybmVsX3dpdGhfbG9jYWxfc2NyYXRjaCIsICJwbGF0Zm9ybV90YXJnZXQiOiA0LCAia2VybmVsX2Zvcm1hdCI6ICJiaXIiLCAia2VybmVsX3ZlcnNpb24iOiAxLCAia2xpcl9iaW5hcnkiOiB7ImJpbmFyeSI6ICIvdmFyL3RtcC9uZXVyb24tY29tcGlsZS1jYWNoZS9ua2lfMC4zLjArMjM5Mjg3MjE3NTQuZzE4YWExMjcxLzc5YWU5MDQ4YTVkMWY3ZjMvX19tYWluX18ua2VybmVsX3dpdGhfbG9jYWxfc2NyYXRjaF83OWFlOTA0OGE1ZDFmN2YzLmpzb24iLCAiaW5wdXRfbmFtZXMiOiBbInhfaW4iLCAid19tYXQiXSwgIm91dHB1dF9uYW1lcyI6IFsib3V0cHV0XzAiXSwgInZlcnNpb25faWRlbnRpZmllciI6ICIiLCAiYWxpYXNlcyI6IFtdfSwgImdyaWQiOiAxLCAiaGFzX2NvbGxlY3RpdmVzIjogZmFsc2UsICJtYWNfY291bnQiOiAzMjc2OH0=', use_opaque_access=True, id=4, parent=v0, dl=m1.DebugLocation(tensor_op_name="_custom-call.1", file="", line=0, column=0, hlo_id=15))
v0.markOutput(v3)
v0.id=5
ir=v0
